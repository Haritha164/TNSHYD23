package p2;
import p1.*;

class B {

	public static void main(String[] args) {
A obj=new A();
obj.display();

	}

}
