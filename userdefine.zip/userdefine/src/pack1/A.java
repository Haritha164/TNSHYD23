package pack1;

public class A {
	public void msg()
	{
	System.out.println("hello A");
	}

}
