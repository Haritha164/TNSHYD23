package P1;

public class A1
{
 public void display() 
	{
		System.out.println("tns session");
}

}
