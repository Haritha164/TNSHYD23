package p2;
import P1.*;
public class B {

	public static void main(String[] args) {
A1 obj=new A1();
obj.display();
	}

}
