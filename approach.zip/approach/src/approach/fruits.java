package approach;

public class fruits
 {
	int a=20;
	 static int b=30;
	 int display()
	 {
		 return 10;
	 }
	 static void display1()
	 {
		 System.out.println(10); 
	 }
  public static void main(String args[])
  {
	  fruits b1=new fruits();
	  System.out.println(b1.a);
	  b1.display();
	  System.out.println(fruits.b);
	  fruits.display1();
	  }
  }