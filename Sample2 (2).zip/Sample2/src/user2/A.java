package user2;

public class A {
	public void msg()
	{
	System.out.println("hello A");
	}

}
