package user2;

public class B {
	public void msg()
	{
		System.out.println("hello B");
	}

}
