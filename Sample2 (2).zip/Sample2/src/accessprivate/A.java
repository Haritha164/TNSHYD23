package accessprivate;


class A {
	 int a=10;
	 private void display()
	 {
		 System.out.println("tns sessions");	
	 }
	 public static void main(String[] args) {
		 A a1=new A();
		 System.out.println(a1.a);
		 a1.display();
		 }


}
