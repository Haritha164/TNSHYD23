package accesspublic2;
import accesspublic1.*;
class B extends A{

		public static void main(String[] args) {
	A obj=new A();
	obj.display();

		}
}

