package approach2;

public class Bike {
	public static void main(String[] args) {
		Cars a1=new Cars();
		System.out.println(a1.b);
		a1.display();
		System.out.println(Cars.c);
		Cars.show();
	}
}
