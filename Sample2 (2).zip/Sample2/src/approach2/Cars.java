package approach2;

public class Cars {

		int b=20;
   static  int c=50;
   int display()
{
	return 10;
}
 static void show()
{
	System.out.println(10);
	}
}


