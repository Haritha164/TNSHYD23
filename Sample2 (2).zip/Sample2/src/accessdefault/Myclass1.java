package accessdefault;

public class Myclass1 {
	void display()
	{
		System.out.println("hello world");
	}
}
