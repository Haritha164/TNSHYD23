package user1;
import user2.*;
	public class C {
	public static void main(String[] args)
	{
		A obj=new A();
		B obj1= new B();
		
		obj.msg();
		obj1.msg();
	}
	}



