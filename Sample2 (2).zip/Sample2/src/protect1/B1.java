package protect1;
import protect.*;

	public class B1 {

		public static void main(String[] args) {
	A1 obj=new A1();
	obj.display();
		}

}
