package approach2;
 class Cars {
		int b=20;
   static  int c=30;
   int display()
{
	return 10;
}
 static void show()
{
	System.out.println(10);
	}
}
