/**
 * 
 */
/**
 * 
 */
module approach2 {
}